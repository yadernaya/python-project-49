### Hexlet tests and linter status:


[![Actions Status](https://github.com/yadernaya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/yadernaya/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/97e008e59d0facc7c46d/maintainability)](https://codeclimate.com/github/yadernaya/python-project-49/maintainability)
