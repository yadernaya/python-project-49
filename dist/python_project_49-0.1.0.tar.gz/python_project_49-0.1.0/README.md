### Hexlet tests and linter status:


[![Actions Status](https://github.com/yadernaya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/yadernaya/python-project-49/actions)


[![Maintainability](https://api.codeclimate.com/v1/badges/97e008e59d0facc7c46d/maintainability)](https://codeclimate.com/github/yadernaya/python-project-49/maintainability)

https://asciinema.org/a/wszytvT7fZq59Y27xZJr0GNFd #brain-even
https://asciinema.org/a/XiG51sSlHsuSdHl1CZ5eaJJ5a #brain-calc
